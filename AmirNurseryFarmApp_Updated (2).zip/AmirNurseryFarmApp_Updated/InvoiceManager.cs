
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace AmirNurseryFarmApp
{
    public class InvoiceManager
    {
        private readonly string[] _plants = {
            // Entire updated plant list here...
            "Antirrhinum"
        };

        public void AlterInvoiceItem(int invoiceId, int itemId, string newPlantName, int newQuantity, decimal newPrice)
        {
            var invoice = GetInvoiceById(invoiceId);
            var item = invoice.Items.FirstOrDefault(i => i.ItemId == itemId);
            if (item != null)
            {
                item.PlantName = newPlantName;
                item.Quantity = newQuantity;
                item.Price = newPrice;
            }
            SaveInvoice(invoice);
        }

        public void DeleteInvoiceItem(int invoiceId, int itemId)
        {
            var invoice = GetInvoiceById(invoiceId);
            var item = invoice.Items.FirstOrDefault(i => i.ItemId == itemId);
            if (item != null)
            {
                invoice.Items.Remove(item);
            }
            SaveInvoice(invoice);
        }

        public void GeneratePdfInvoice(int invoiceId)
        {
            var invoice = GetInvoiceById(invoiceId);

            Document doc = new Document();
            PdfWriter.GetInstance(doc, new FileStream($"Invoice_{invoiceId}.pdf", FileMode.Create));
            doc.Open();

            doc.Add(new Paragraph($"Invoice ID: {invoiceId}"));
            doc.Add(new Paragraph($"Date: {invoice.Date}"));
            // Add other invoice details and items

            doc.Close();
        }

        private Invoice GetInvoiceById(int invoiceId)
        {
            // Mock method to get invoice by ID
            return new Invoice();
        }

        private void SaveInvoice(Invoice invoice)
        {
            // Mock method to save invoice
        }
    }

    public class Invoice
    {
        public int InvoiceId { get; set; }
        public DateTime Date { get; set; }
        public List<InvoiceItem> Items { get; set; }
    }

    public class InvoiceItem
    {
        public int ItemId { get; set; }
        public string PlantName { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
    }
}
